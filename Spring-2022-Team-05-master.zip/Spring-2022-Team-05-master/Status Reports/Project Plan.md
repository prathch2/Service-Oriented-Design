# *CSnnn Project Name*
## **Sponsor:**

**Students' Names:**

**Mentor:**

**Faculty Advisor:**

**Project:**

**Project Description:**

**Problem Definition:**

**Deliverables**

**Coding Plan**

| Week | Tasks | Goals |
|------|-------|-------|
| _Week 1_ | _Task 1_ | _Goal 1_ |
| ... | ... | ... |
